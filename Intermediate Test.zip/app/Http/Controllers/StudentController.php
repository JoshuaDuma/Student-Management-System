<?php

namespace App\Http\Controllers;

class StudentController extends Controller
{
    
}
