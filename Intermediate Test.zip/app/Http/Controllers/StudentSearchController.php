<?php

namespace App\Http\Controllers;

class StudentSearchController extends Controller
{
}
